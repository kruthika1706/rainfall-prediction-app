Rainfall Prediction — Fullstack Starter (Backend + Frontend)
============================================================

What you received:
- backend/  -> FastAPI server (api.py) — expects your model artifacts in backend/artifacts/
- frontend/ -> React (Vite) starter with a simple UI to call the API

Important: *This zip does NOT contain your trained model files* (ann.h5, lstm.h5, scaler.pkl).
After training, copy those files into backend/artifacts/ (see backend/README.md).

Quick start (Windows):
----------------------
1) Unzip the project and open two terminals.
2) Backend:
   cd rainfall_project/backend
   python -m venv venv
   venv\Scripts\activate
   pip install -r requirements.txt
   uvicorn api:app --reload --port 8000

3) Frontend:
   cd rainfall_project/frontend
   npm install
   npm run dev

4) Open the frontend URL (Vite) and set API Base URL to http://127.0.0.1:8000