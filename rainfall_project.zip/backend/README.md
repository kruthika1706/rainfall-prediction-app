Backend (FastAPI) - where to put your trained model artifacts
------------------------------------------------------------

1) After training in your Python script, save the artifacts into backend/artifacts/ :
   - ann.h5          (ANN model saved with Keras .save())
   - lstm.h5         (LSTM model saved with Keras .save())
   - scaler.pkl      (joblib.dump(scaler, 'scaler.pkl'))
   - features.json   (JSON list with the feature order)

Example save snippet to run in your training environment:
```python
import os, joblib, json
os.makedirs('backend/artifacts', exist_ok=True)
ann_model.save('backend/artifacts/ann.h5')
lstm_model.save('backend/artifacts/lstm.h5')
joblib.dump(scaler, 'backend/artifacts/scaler.pkl')
features = ['Temperature','Humidity','Wind Speed','Precipitation','Cloud Cover','Pressure']
with open('backend/artifacts/features.json','w') as f:
    json.dump(features, f)
```

2) Create and activate venv, then install requirements:
   python -m venv venv
   # Windows:
   venv\Scripts\activate
   # Mac/Linux:
   source venv/bin/activate
   pip install -r requirements.txt

3) Run the API (from backend/):
   uvicorn api:app --reload --port 8000
4) Health check: http://127.0.0.1:8000/health