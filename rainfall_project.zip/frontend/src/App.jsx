import React, { useState } from "react";
import axios from "axios";

const DEFAULT_FEATURES = [
  { key: "Temperature", label: "Temperature (°C)" },
  { key: "Humidity", label: "Humidity (%)" },
  { key: "Wind Speed", label: "Wind Speed (m/s)" },
  { key: "Precipitation", label: "Precipitation (mm)" },
  { key: "Cloud Cover", label: "Cloud Cover (%)" },
  { key: "Pressure", label: "Pressure (hPa)" }
];

export default function App() {
  const [apiBase, setApiBase] = useState("http://127.0.0.1:8000");
  const [inputs, setInputs] = useState(Object.fromEntries(DEFAULT_FEATURES.map(f => [f.key, ""])));
  const [prediction, setPrediction] = useState(null);
  const [csvText, setCsvText] = useState("");
  const [batchResults, setBatchResults] = useState([]);

  function buildFeatureArray() {
    return DEFAULT_FEATURES.map(f => parseFloat(inputs[f.key] || 0));
  }

  async function predictSingle() {
    try {
      const features = buildFeatureArray();
      const res = await axios.post(`${apiBase.replace(/\\/$/, "")}/predict`, { features });
      setPrediction(res.data.prediction);
    } catch (e) {
      alert("Prediction failed: " + (e?.response?.data?.detail || e.message));
    }
  }

  function parseCsv(text) {
    const lines = text.split(/\\r?\\n/).map(l=>l.trim()).filter(Boolean);
    if(!lines.length) return [];
    const first = lines[0].split(/,|\\t/).map(s=>s.trim());
    const headerLooksNamed = first.some(h=>/[a-zA-Z]/.test(h));
    const rows=[];
    if(headerLooksNamed) {
      const header = first.map(h=>h.toLowerCase());
      for(let i=1;i<lines.length;i++){
        const cols = lines[i].split(/,|\\t/).map(s=>s.trim());
        const row = DEFAULT_FEATURES.map(f => {
          const idx = header.indexOf(f.key.toLowerCase());
          return idx>=0 ? parseFloat(cols[idx]||0) : 0;
        });
        rows.push(row);
      }
    } else {
      for(const l of lines) {
        const nums = l.split(/,|\\t/).map(s=>parseFloat(s)||0);
        rows.push(nums);
      }
    }
    return rows;
  }

  async function runBatch() {
    try {
      const rows = parseCsv(csvText);
      if(!rows.length) return alert("No rows found");
      const res = await axios.post(`${apiBase.replace(/\\/$/, "")}/predict-batch`, { rows });
      setBatchResults(res.data.predictions || []);
    } catch (e) {
      alert("Batch prediction failed: " + (e?.response?.data?.detail || e.message));
    }
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h1 className="text-2xl font-semibold mb-4">Rainfall Prediction Dashboard</h1>

      <div className="bg-white p-4 rounded-lg shadow space-y-4">
        <label className="block">API Base URL</label>
        <input className="border p-2 rounded w-full" value={apiBase} onChange={e=>setApiBase(e.target.value)} />

        <h2 className="text-lg font-medium mt-4">Single Prediction</h2>
        <div className="grid grid-cols-2 gap-2">
          {DEFAULT_FEATURES.map(f=> (
            <div key={f.key}>
              <label className="block text-sm">{f.label}</label>
              <input value={inputs[f.key]} onChange={e=>setInputs(s=>({...s,[f.key]:e.target.value}))} className="border p-2 rounded w-full" />
            </div>
          ))}
        </div>
        <div className="flex gap-2 mt-3">
          <button onClick={predictSingle} className="bg-blue-600 text-white px-4 py-2 rounded">Predict</button>
          <div className="flex items-center">Result: <span className="ml-2 font-semibold">{prediction!==null? prediction.toFixed(3): "-"}</span></div>
        </div>
      </div>

      <div className="bg-white p-4 rounded-lg shadow mt-6">
        <h2 className="text-lg font-medium">Batch (CSV)</h2>
        <textarea value={csvText} onChange={e=>setCsvText(e.target.value)} placeholder="paste CSV rows or header+rows" className="w-full h-40 border p-2 rounded"></textarea>
        <div className="flex gap-2 mt-3">
          <button onClick={runBatch} className="bg-green-600 text-white px-4 py-2 rounded">Run Batch</button>
        </div>
        {batchResults.length>0 && (
          <table className="mt-4 w-full text-sm">
            <thead><tr><th className="text-left">#</th><th className="text-left">Prediction</th></tr></thead>
            <tbody>
              {batchResults.map((v,i)=> <tr key={i}><td>{i+1}</td><td>{v.toFixed(3)}</td></tr>)}
            </tbody>
          </table>
        )}
      </div>

      <div className="text-xs text-gray-500 mt-6">
        Note: Place your trained models in backend/artifacts/ as described in backend/README.md
      </div>
    </div>
  );
}
