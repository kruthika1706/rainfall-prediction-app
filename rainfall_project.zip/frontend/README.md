Frontend (Vite + React) - quick run
----------------------------------

1) Install dependencies:
   cd frontend
   npm install

2) Start dev server:
   npm run dev
   # open the URL printed by Vite (usually http://localhost:5173)

3) In the app, set API Base URL to the running backend (default: http://127.0.0.1:8000).